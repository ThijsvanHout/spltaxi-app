<?php include("header.php"); ?>
<div class="about-us-area div-padding">
<div class="container">
<div class="row">
<div class="col-lg-6">
<div class="about-us-text">
<h2 class="div-title pb-4 mb-4">Trusted Cab Services <span class="d-block">in the World</span></h2>
<p>
Curabitur placerat cursus nisi nec pharetra. Proin quis tortor fringilla, placerat nisi nec, auctor ex. Donec commodo orci ac lectus mattis, sed interdum sem scelerisque. Vivamus at euismod magna. Aenean semper risus nec dolor bibendum cursus. Donec eu odio eu ligula sagittis fringilla. Phasellus vulputate velit eu vehicula auctor. Nam vel pellentesque libero.
</p>
<p>
Fusce dui metus, interdum ac malesuada eu, ornare nec neque. Fusce hendrerit, tortor id egestas rutrum, orci lorem lacinia velit, sed mollis augue diam eget ipsum. Curabitur euismod, tellus sit amet tincidunt semper, dui odio pharetra orci, sed molestie odio libero sed libero. Sed volutpat ornare mauris. Sed gravida pulvinar urna, eget euismod mi mattis a.
</p>
<a href="#" class="button button-dark">Read More</a>
</div>
</div>
</div>
</div>
</div>
<?php include("footer.php"); ?>