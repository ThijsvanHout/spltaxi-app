@extends('frontend.index')


@section('main-section')
<div class="div-padding">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="about-us-text">

@if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    
                    <h2>Booking Details</h2>
                   

                    <p><strong>Name:</strong> {{ $booking->name }}</p>
                    <p><strong>Pickup Address:</strong> {{ $booking->pickup_address }}</p>
                    <p><strong>Number of Persons:</strong> {{ $booking->no_of_persons }}</p>
                    <p><strong>Pickup Date:</strong> {{ $booking->pickup_date }}</p>
                    <p><strong>Pickup Time:</strong> {{ $booking->pickup_time }}</p>
                    <p><strong>Destination:</strong> {{ $booking->destination }}</p>
                    <!-- Add more booking details here -->

                    <form action="{{ route('driver-confirmation-response', $booking->assign_id) }}" method="POST">
                        @csrf
                        <button type="submit" name="status" value="accepted" class="btn btn-success">Accept</button>
                        <button type="submit" name="status" value="rejected" class="btn btn-danger">Reject</button>
                    </form>
                </div>
</div>
</div>
</div>
</div>
@endsection