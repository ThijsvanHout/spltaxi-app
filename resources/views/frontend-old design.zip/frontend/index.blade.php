@include('frontend.header')

@yield('main-section')  

@include('frontend.footer')